#!/usr/bin/env python
# coding: utf-8

# ## Part 1

# In[1]:


# Import libraries
import cv2
import numpy as np
import matplotlib.pyplot as plt

from tqdm import tqdm


# In[2]:


# load the image
image = cv2.imread('image.jpg')

# convert to grayscale
image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# convert to float32
image_gray = np.float32(image_gray)


# In[3]:


# Apply Harris Corner Detector
scores = cv2.cornerHarris(
    src=image_gray, blockSize=2, ksize=3, k=0.04)

# Apply the threshold and change corners intensity to red
opencv_result =  image.copy()
opencv_result[scores>0.01*scores.max()] = [0, 0, 255]

# Plot the result
opencv_result = cv2.cvtColor(opencv_result, cv2.COLOR_BGR2RGB)
plt.imshow(opencv_result)
plt.axis('off')
plt.show()


# ## Part 2

# In[4]:


# Harris corner detector implementation from scratch
def harris(img, k):
    # make a copy
    img_cpy = img.copy()
    
    # convert to grayscale
    img1_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img1_gray = np.float32(img1_gray)
   
    # compute derivative on X direction
    dx = cv2.Sobel(img1_gray, ddepth=-1, dx=1, dy=0)
    
    # compute derivative on Y direction
    dy = cv2.Sobel(img1_gray, ddepth=-1, dx=0, dy=1)
    
    # square of derivatives
    dx2 = np.square(dx)
    dy2 = np.square(dy)
    dxdy = dx*dy
    
    # apply gaussian weights
    g_dx2 = cv2.GaussianBlur(dx2, (3, 3), sigmaX=0, sigmaY=0)
    g_dy2 = cv2.GaussianBlur(dy2, (3, 3), sigmaX=0, sigmaY=0)
    g_dxdy = cv2.GaussianBlur(dxdy, (3, 3), sigmaX=0, sigmaY=0)
    
    # calculate cornerness R = det - k*(trace)
    harris = g_dx2*g_dy2 - np.square(g_dxdy) - k * (g_dx2 + g_dy2) 
    
    # find all points above threshold
    loc = np.where(harris >= 0.01*np.max(harris))
    
    return loc, harris


# In[5]:


# apply harris function on the image
loc, harr = harris(img=image, k=0.04)


# In[6]:


# find local maximum by 3x3 window
harr_thresh = harr.copy()

# apply threshold
harr_thresh[harr_thresh < 0.01*harr.max()] = 0
threshold = 0.01*harr_thresh.max()

# padding for sliding the 3x3 window
harr_paded = np.pad(harr_thresh, pad_width=1, mode='constant')

# slide 3x3 window and save local maxima coordinates
corner_coordinates = []

# foor loop on all pixels' scores
for i in tqdm(range(1,harr_thresh.shape[0])):
    for j in range(1,harr_thresh.shape[1]):
        
        # extract the all 8 neighbors
        neighbor_a = harr_paded[i-1, j-1]
        neighbor_b = harr_paded[i-1, j] 
        neighbor_c = harr_paded[i-1, j+1]
        neighbor_d = harr_paded[i, j-1] 
        neighbor_e = harr_paded[i, j+1] 
        neighbor_f = harr_paded[i+1, j-1]
        neighbor_g = harr_paded[i+1, j]
        neighbor_h = harr_paded[i+1, j+1]
        neighbers = np.array([
            neighbor_a, neighbor_b, neighbor_c, neighbor_d,
            neighbor_e, neighbor_f, neighbor_g, neighbor_h])
        
        # comapare central pixel with its 8 neighbors
        if (harr_thresh[i,j] >= neighbers).all():
            if harr_thresh[i,j]>= threshold:
                corner_coordinates.append((j, i))


# In[7]:


# change corners intensity to red
final_locmax = image.copy()
for pt in corner_coordinates:
    final_locmax[pt[1], pt[0], :] = [0, 0, 255]

# plot the result
final_locmax = cv2.cvtColor(final_locmax, cv2.COLOR_BGR2RGB)

# create a figure of size 15, 15
fig, ax = plt.subplots(1, 2, figsize=(15, 15))

# plot my output
ax[0].imshow(final_locmax)
ax[0].set_title('My Output')
ax[0].axis('off')

# plot opencv output
ax[1].imshow(opencv_result)
ax[1].set_title('Opencv Output')
ax[1].axis('off')
plt.show()


# ## Part 3

# با توجه به اینکه در مرحله اخر بیشنیه های محلی را با استفاده از یک پنجره سه در سه پیدا کردیم تعداد گوشه ها به مراتب کمتر شد نسبت به گوشه های پیدا شده توسط کتابخانه.که میتوان این مرحله را سختگیرانه تر اجرا کرد و به جای پنجره سه درسه از پنجره بزرگتری استفاده کرد که در این صورت هر پیکسل با همسایه های بیشتری مقایسه میشود و بدین صورت تعداد گوشه های با امتیاز کمتر کاهش میابد.
