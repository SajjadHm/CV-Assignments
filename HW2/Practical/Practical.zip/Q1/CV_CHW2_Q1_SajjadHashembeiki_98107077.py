#!/usr/bin/env python
# coding: utf-8

# In[112]:


# Import libraries
import cv2
import scipy
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


# ## Part A

# In[113]:


# Load .csv file
df = pd.read_csv('yalefaces.csv')

# select the images name column
images_name = df['5']

# Load images and convert to grayscale
images = []
for image in images_name:
    img = cv2.imread(f'yalefaces/{image}')
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    images.append(img_gray)


# In[114]:


# create model
path = 'haarcascade_frontalface_default.xml'
detector = cv2.CascadeClassifier(path)

# detect faces by the detector
images_roi = []
for image in images:
    img_gray = image
    results = detector.detectMultiScale(
        img_gray, scaleFactor=1.05, minNeighbors=3,
        minSize=(30, 30), flags=cv2.CASCADE_SCALE_IMAGE)
    
    # extract the coordinates
    x = results[0][0]
    y = results[0][1]
    w = results[0][2]
    h = results[0][3]

    # crop ROI
    roi = img_gray[y:y+h, x:x+w]
    images_roi.append(roi)


# In[115]:


# Resize the ROIs
final_images = []
for img in images_roi:
    resized = cv2.resize(
        img, (130, 130), interpolation = cv2.INTER_AREA)
    final_images.append(resized)


# In[116]:


# create labels list 0-14
labels = []
for label in df['0']:
    labels.append(int(label[7:])) 

labels = np.array(labels) - 1

# select an index of each subject randomly
selected_index = []
for i in range(15):
    selected_index.append(
        np.random.choice(np.where(labels==i)[0],1)[0])

# plot the images
fig, ax = plt.subplots(3,5)
for i in range(3):
    for j in range(5):
        ax[i][j].imshow(images[selected_index[i*5+j]], cmap='gray')
        ax[i][j].axis('off')
        ax[i][j].set_title(f'Subject {i*5+j+1}')


# ## Part B

# In[117]:


# create labels list 0-14
labels = []
for label in df['0']:
    labels.append(int(label[7:]))    
labels = np.array(labels) - 1
print(f'Labels:{labels}')


# ## Part C

# In[118]:


# split dataset into train and test
x_train, x_test, y_train, y_test = train_test_split(
    final_images, labels,test_size=0.1, random_state=42)


# ## Part D

# In[119]:


# create model
model = cv2.face.LBPHFaceRecognizer.create()

# train the model
model.train(x_train, y_train)


# ### Questions

# **- 1 Explain how does it work.**

# **Haar Cascade Classifier** : Haar-like features are the differences of the sums of the intensities in rectangular areas, and we compute them very fast by integral image. There are many features in a window, there are about 180k Haar-like features in a 24x24 window but in the detection we don't use all of them. Adaboost is used for selecting most discriminative features out of 180k features, finally 6k features are selected.
# The classifier is trained using positive and negative samples. Positive samples contain face and negative samples are non-face. 
# 
# The Haar cascade classifier is organized into a cascade of stages, where each stage is an Adaboost as a weak learner. In early stages we perform classification with high FP rate, each stage that we proceed, we decrease FP rate and use more features and this is a cascade architecture.

# **LBPHFaceRecognizer** : First we calculate LBP for each pixel. It works by comparing each pixel in an image with its neighbors. The result is a binary pattern (if we use a 3x3 kernel we hava a 8 bit binary number), also LBP is known for its robustness to variations in lighting conditions and facial expressions. Assume we a have a window, for creating a feature vector we calculate LBP for each pixel in the window, divide the window into cells for example cells of size 8x8 pixels,then we compute histogram of the LBP numbers over the cell, and finally concatenate the histograms of all cells.
# 
# During the training phase, LBPHFaceRecognizer is trained on a dataset of face images. For each person, a set of positive samples (images of that person) is provided. The algorithm computes LBP histograms for each region in these positive samples and builds a model that represents the distribution of local patterns for each individual.
# 
# In the recognition phase, the LBPHFaceRecognizer is given an input image and computes the LBP histograms for each region in the image. It then compares these histograms with the histograms stored in the trained model. The algorithm determines which individual in the training set has the most similar LBP pattern distribution to the input image.
# 
# Finall, if the similarity between the input image and a stored model is above a certain threshold, the algorithm recognizes the face as belonging to the person represented by that model. Otherwise, it considers the face as unknown.

# **- 2 Report model accuracy.**

# In[120]:


# predicton on test images
y_preds = []
for test in x_test:
    label, confidence = model.predict(test)
    y_preds.append(label)
    
# calculate model accuracy on test set 
acc = accuracy_score(y_test, y_preds)
print(f'Accuracy on Testset:{acc.round(2) * 100}%')


# **- 3 Prediction on rotated image.**

# In[121]:


# load the image and convert to grayscale
image_test = cv2.imread('image.jpg')
image_test = cv2.cvtColor(image_test, cv2.COLOR_BGR2GRAY)

# create Haar Cascade Classifier model for eye detection
path_eye = 'haarcascade_eye.xml'
eye_detector = cv2.CascadeClassifier(path_eye)

# detect eyes on image_test
eye_result = eye_detector.detectMultiScale(image_test)

# extract eyes coordinates
eye_1 = eye_result[0]
eye_2 = eye_result[1]

x_1 = eye_1[0]
y_1 = eye_1[1]
w_1 = eye_1[2]
h_1 = eye_1[3]

x_2 = eye_2[0]
y_2 = eye_2[1]
w_2 = eye_2[2]
h_2 = eye_2[3]

# center points coordinates
x_center_1 = x_1 + w_1//2
y_center_1 = y_1 + h_1//2
x_center_2 = x_2 + w_2//2
y_center_2 = y_2 + h_2//2

# calculate angle of the rotation and convert to degree
theta = np.arctan2((x_center_2-x_center_1)/(y_center_2-y_center_1), 3)
deg = theta*180/np.pi
rotated_img = scipy.ndimage.rotate(image_test, deg)

# rotate image_test
rotated_img = scipy.ndimage.rotate(image_test, deg)

# Apply face detection on rotated_img
final_result = detector.detectMultiScale(
        rotated_img, scaleFactor=1.05, minNeighbors=3,
        minSize=(30, 30), flags=cv2.CASCADE_SCALE_IMAGE)
    
# extract the ROI coordinates
x = final_result[0][0]
y = final_result[0][1]
w = final_result[0][2]
h = final_result[0][3]

# crop ROI
test_roi = rotated_img[y:y+h, x:x+w]

# resize to 130x130
resized_roi = cv2.resize(
    test_roi, (130, 130), interpolation=cv2.INTER_AREA)

# predict on the ROI
label, confidence = model.predict(resized_roi)

# print result
print(f'Predicted label : Subject{label+1}')
print('Ground truth : Subject3')

