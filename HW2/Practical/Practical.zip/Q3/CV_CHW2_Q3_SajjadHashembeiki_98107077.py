#!/usr/bin/env python
# coding: utf-8

# ## Part 1

# باتوجه به اینکه مقدار مرکزی فیلتر دوم و چهارم تفاوت بیشتری نسبت به مقادیر اطراف خود دارند (به تعبیری اون کلاه مکزیکی تیز تر است) انتظار داریم عملکرد بهتری در لبه یابی داشته باشند. همینطور از لحاظ وزن پیکسل ها باتوجه به اینکه فیلتر چهارم یک وزن گوسی طور دارد یعنی هرچه از مرکز دورتر میشویم مقادیر به نسبت فاصله کاهش میابند،پس فیلتر چهارم قوی ترین عملکرد را خواهد داشت و سپس فیلتر دوم در جایگاه بعدی قرار دارد.بین فیلتر اول و سوم، در فیلتر اول تفاوت مقدار مرکزی با مقادیر کناری بیشتر از همین مقدار در فیلتر سوم میباشد.بنابراین فیلتر سوم ضعیفترین عملکرد را خواهد داشت.

# - The best : d
# - The worst : c

# ## Part 2

# In[1]:


import cv2
import numpy as np
import matplotlib.pyplot as plt


# In[2]:


# load the image
image = cv2.imread('image.png')
# convert the image from BGR to Grayscale
img_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


# In[3]:


# Define the filters
# filter a
a_filter = np.array([[0, -1, 0], [-1, 4, -1], [0, -1, 0]])
# filter b
b_filter = np.array([[-1, -1, -1], [-1, 8, -1], [-1, -1, -1]])
# filter c
c_filter = np.array([[1, -2, 1], [-2, 4, -2], [1, -2, 1]])
# filter d
d_filter = np.array([[1, 2, 1], [2, -12, 2], [1, 2, 1]])


# In[4]:


# Define a function to apply filters  
def apply_filter(img, kernel):
    filtered_img = cv2.filter2D(src=np.float64(img), ddepth=-1, 
                               kernel=kernel)
    max_value = np.max(filtered_img)
    min_value = np.min(filtered_img)
    
    return filtered_img, max_value, min_value


# In[5]:


# Apply filters on the img_gray by the apply_filter
filtered_img_a, max_a, min_a = apply_filter(img_gray, a_filter)
filtered_img_b, max_b, min_b = apply_filter(img_gray, b_filter)
filtered_img_c, max_c, min_c = apply_filter(img_gray, c_filter)
filtered_img_d, max_d, min_d = apply_filter(img_gray, d_filter)


# In[6]:


# print max_value and min_value of each filtered_img
print(f'filter a: Max Value={max_a}, Min Value={min_a}\n')
print(f'filter b: Max Value={max_b}, Min Value={min_b}\n')
print(f'filter c: Max Value={max_c}, Min Value={min_c}\n')
print(f'filter d: Max Value={max_d}, Min Value={min_d}')


# In[7]:


# Plot the filtered image
cv2.imshow('filtered_img_a', filtered_img_a)
cv2.imshow('filtered_img_b', filtered_img_b)
cv2.imshow('filtered_img_c', filtered_img_c)
cv2.imshow('filtered_img_d', filtered_img_d)
cv2.waitKey(0)
cv2.destroyAllWindows()


# Filter ranking based on edge detection quality:
# - d
# - b
# - a
# - c
